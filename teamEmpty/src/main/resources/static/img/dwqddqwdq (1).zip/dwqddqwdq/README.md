# maplestory

## Quick Start

### Setting

- 해상도 : 1280 X 720
- 그래픽 품질 : 매우 높음