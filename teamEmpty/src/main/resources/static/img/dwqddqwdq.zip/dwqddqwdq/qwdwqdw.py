import pygetwindow as gw
import pyautogui
from PIL import Image
import time
import keyboard
import win32api
import win32gui
import win32con
import win32ui
import cv2
import numpy as np
from ctypes import windll
import sys

def GetHandleName(name):
    return win32gui.FindWindow(None, name)

def GetWindowRect(hwnd):
    return win32gui.GetWindowRect(hwnd)

def ImagePosExtract(handle, path, click_x = 0, click_y = 0, threshold=.99):
    left, top, right, bot = win32gui.GetWindowRect(handle)
    w = right - left
    h = bot - top

    hwndDC = win32gui.GetWindowDC(handle)
    mfcDC  = win32ui.CreateDCFromHandle(hwndDC)
    saveDC = mfcDC.CreateCompatibleDC()

    saveBitMap = win32ui.CreateBitmap()
    saveBitMap.CreateCompatibleBitmap(mfcDC, w, h)

    saveDC.SelectObject(saveBitMap)

    result = windll.user32.PrintWindow(handle, saveDC.GetSafeHdc(), 0)

    bmpinfo = saveBitMap.GetInfo()
    bmpstr = saveBitMap.GetBitmapBits(True)

    im = Image.frombuffer(
        'RGB',
        (bmpinfo['bmWidth'], bmpinfo['bmHeight']),
        bmpstr, 'raw', 'BGRX', 0, 1)

    win32gui.DeleteObject(saveBitMap.GetHandle())
    saveDC.DeleteDC()
    mfcDC.DeleteDC()
    win32gui.ReleaseDC(handle, hwndDC)

    img_rgb = np.array(im)
    img_rgb = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2RGB)

    template = cv2.imread(path)
    w, h = template.shape[:-1]

    res = cv2.matchTemplate(img_rgb, template, cv2.TM_CCOEFF_NORMED)
    loc = np.where(res >= threshold)
    imgPos = []

    for pt in zip(*loc[::-1]):  # Switch collumns and rows
        imgPos.append(pt[0] + x + h // 2 + click_x)
        imgPos.append(pt[1] + y + w // 2 + click_y)

    if len(imgPos) == 0:
        return None

    return imgPos[0], imgPos[1]


# 특정 프로세스의 이름을 지정합니다.
target_process_name = "MapleStory"

hwnd = GetHandleName(target_process_name)
x, y, width, height = GetWindowRect(hwnd)

# 특정 프로세스를 찾습니다.
process_window = None
for window in gw.getAllTitles():
    if target_process_name.lower() in window.lower():
        process_window = gw.getWindowsWithTitle(window)[0]
        break

if not process_window:
    print(f"{target_process_name} 프로세스를 찾을 수 없습니다.")
    exit()

# 프로세스 창을 활성화합니다.
process_window.activate()

def find_image_in_process(image_path, threshold=.99):
    image_location = ImagePosExtract(hwnd, image_path, threshold=threshold)

    if image_location:
        x, y = image_location
        print(f"이미지를 찾아 마우스를 이동하고 클릭했습니다. 위치: ({x}, {y})")
        return 1
    else:
        print("이미지를 찾을 수 없습니다.")
        return 0

def move_mouse_to_image_in_process(image_path, click_x = 0, click_y = 0, isIgnore = False, threshold=.99):
    image_location = ImagePosExtract(hwnd, image_path, click_x, click_y, threshold=threshold)

    if isIgnore and not image_location:
        return 0

    if image_location:
        x, y = image_location
        pyautogui.moveTo(x, y)
        print(f"이미지를 찾아 마우스를 이동하고 클릭했습니다. 위치: ({x}, {y})")
    else:
        print("이미지를 찾을 수 없습니다.")
    
    time.sleep(.5)

def move_mouse_click_to_image_in_process(image_path, click_x = 0, click_y = 0, isIgnore = False, threshold=.99):
    image_location = ImagePosExtract(hwnd, image_path, click_x, click_y, threshold=threshold)

    if isIgnore and not image_location:
        return 0

    if image_location:
        x, y = image_location
        pyautogui.moveTo(x, y)
        pyautogui.click()
        print(f"이미지를 찾아 마우스를 이동하고 클릭했습니다. 위치: ({x}, {y})")
        time.sleep(.5)
        return 1
    else:
        print("이미지를 찾을 수 없습니다.")
        time.sleep(.5)
        return 0

def drag_mouse_down_up(drag_distance, wait_time=1):
    current_x, current_y = pyautogui.position()
    pyautogui.mouseDown(x=current_x, y=current_y)
    time.sleep(wait_time)
    pyautogui.mouseUp(x=current_x, y=current_y + drag_distance)

def scroll_mouse_down(scroll_amount=-500):
    pyautogui.middleClick()
    pyautogui.scroll(-500)

def scroll_mouse_up(scroll_amount=500):
    pyautogui.middleClick()
    pyautogui.scroll(500)

def click():
    pyautogui.click()

def double_click():
    pyautogui.doubleClick()

def double_click_and_enter():
    pyautogui.doubleClick()
    time.sleep(0.5)
    pyautogui.typewrite(['enter'])

def enter():
    pyautogui.typewrite(['enter'])

def press_key(key):
    keyboard.press(key)
    time.sleep(0.1)
    keyboard.release(key)

def press_backtick():
    keyboard.press_and_release('`')

def press_esc():
    keyboard.press_and_release('esc')

def press_arrow_down():
    pyautogui.press('down')

def press_arrow_left():
    pyautogui.press('left')
    
def press_arrow_right():
    pyautogui.press('right')

def purchaseStar():
    time.sleep(.5)
    move_mouse_click_to_image_in_process(item_shop_image)
    move_mouse_click_to_image_in_process(consumer_shop_image)
    move_mouse_click_to_image_in_process(alicser_image)
    scroll_mouse_down()
    time.sleep(.5)
    move_mouse_click_to_image_in_process(white_gold_star_image)
    double_click_and_enter()
    time.sleep(.5)
    press_esc()

def purchasePets():
    for i in range(3):
        time.sleep(.5)
        move_mouse_click_to_image_in_process(convenience_shop_image)
        move_mouse_click_to_image_in_process(normal_pet_trade_image)
        time.sleep(.5)
        enter()
        time.sleep(1)
        enter()
        time.sleep(1)
        enter()

def purchaseRings():
    for i, name in enumerate(['qntmxm', 'gufaod']):
        time.sleep(.5)
        move_mouse_click_to_image_in_process(beauty_shop_image)
        move_mouse_click_to_image_in_process(search_cash_image)
        time.sleep(.5)
        pyautogui.write(name)
        time.sleep(.5)
        enter()
        if i == 0:
            for j in range(3):
                press_arrow_down()
        else:
            for j in range(5):
                press_arrow_down()
        time.sleep(.5)
        enter()
        press_arrow_left()
        press_arrow_left()
        time.sleep(.5)
        enter()
        time.sleep(.5)
        press_esc()

def purchaseExpCoupon():
    time.sleep(.5)
    move_mouse_click_to_image_in_process(item_shop_image)
    move_mouse_click_to_image_in_process(coin_shop_image)
    move_mouse_click_to_image_in_process(hunt_coin_shop_image)
    move_mouse_click_to_image_in_process(consumer_tap_image)
    move_mouse_click_to_image_in_process(exp_1_image)
    double_click_and_enter()
    move_mouse_click_to_image_in_process(exp_2_image)
    double_click_and_enter()
    move_mouse_click_to_image_in_process(exp_3_image)
    double_click_and_enter()
    move_mouse_click_to_image_in_process(exp_4_image)
    double_click_and_enter()
    enter()
    press_esc()

def setLinkSkills():
    time.sleep(.5)
    press_key('k')
    move_mouse_click_to_image_in_process(skill0_image)
    time.sleep(.5)
    move_mouse_click_to_image_in_process(link_management_image)
    double_click()
    time.sleep(.5)
    move_mouse_to_image_in_process(link_btn_image)
    linkSkills = {}
    for i in range(1, 11):
        linkSkills['images/link' + str(i) +'.png'] = False

    while not all(value for value in linkSkills.values()):
        while True:
            isStop = False
            for linkSkill in linkSkills:
                if linkSkills[linkSkill]:
                    continue
                if (move_mouse_click_to_image_in_process(linkSkill, 95, 10, True)):
                    print('gdd')
                    linkSkills[linkSkill] = True
                    enter()
                    time.sleep(.5)
                    pyautogui.move(0, -15)
            else:
                isStop = True
            if isStop:
                break
        time.sleep(.5)
        scroll_mouse_down(-1000)
    
    press_esc()
    time.sleep(.5)
    press_esc()
    time.sleep(.5)

def setStates():
    press_key('s')
    time.sleep(.5)
    move_mouse_click_to_image_in_process(ability_point_image, click_x=110, click_y=-10)
    enter()
    time.sleep(.5)
    move_mouse_click_to_image_in_process(hyper_zero_image)
    scroll_mouse_down(-1000)
    scroll_mouse_down(-1000)
    time.sleep(.5)
    for i in range(10):
        move_mouse_click_to_image_in_process(hyper1_image, click_x=110)
        enter()
        time.sleep(.5)
    for i in range(10):
        move_mouse_click_to_image_in_process(hyper2_image, click_x=110)
        enter()
        time.sleep(.5)
    press_esc()
    time.sleep(.5)

def getItemByStorage(itmeCount):
    openStorage()
    move_mouse_click_to_image_in_process(yunhap_shinhwa_image)
    double_click_and_enter()
    enter()
    time.sleep(.5)
    move_mouse_click_to_image_in_process(storageExit_image)
    openStorage()
    move_mouse_click_to_image_in_process(storagehuntCount_image)
    double_click_and_enter()
    enter()
    adjustmentMousePoint()
    move_mouse_click_to_image_in_process(storageCozam_image)
    double_click_and_enter()
    enter()
    adjustmentMousePoint()
    move_mouse_click_to_image_in_process(storage3xExp_image)
    double_click_and_enter()
    enter()
    adjustmentMousePoint()
    move_mouse_click_to_image_in_process(storage50Exp_image)
    double_click_and_enter()
    enter()
    adjustmentMousePoint()
    move_mouse_click_to_image_in_process(storagePirodo_image)
    double_click_and_enter()
    enter()
    adjustmentMousePoint()
    move_mouse_to_image_in_process(storageHip_image, click_y=30)
    for i in range(itmeCount):
        double_click_and_enter()
        enter()
    move_mouse_click_to_image_in_process(storageExit_image)

def openStorage():
    enter()
    pyautogui.write('@ckdrh')
    time.sleep(.5)
    enter()
    time.sleep(.5)
    enter()
    solve2Password()
    time.sleep(.5)

def solve2Password():
    time.sleep(.5)
    pyautogui.keyDown('shift')
    time.sleep(.5)
    press_key('1')
    press_key('2')
    press_key('3')
    press_key('1')
    press_key('2')
    pyautogui.keyUp('shift')
    move_mouse_click_to_image_in_process(storageOne_image)
    enter()

def wearitems():
    press_key('i')
    time.sleep(.5)
    move_mouse_to_image_in_process(meCache_image)
    click()
    for i in range(3):
        move_mouse_to_image_in_process(mePet_image)
        double_click()    
        adjustmentMousePoint()
    double_click()    
    move_mouse_to_image_in_process(meChizang_image)
    double_click()    
    adjustmentMousePoint()
    move_mouse_to_image_in_process(meChizangRing_image)
    double_click()    
    adjustmentMousePoint()
    move_mouse_to_image_in_process(meChizangRing2_image)
    double_click()
    adjustmentMousePoint()
    move_mouse_to_image_in_process(meSobi_image)
    click()
    time.sleep(.5)
    move_mouse_to_image_in_process(meSobiBox_image)
    double_click()
    pyautogui.keyDown('enter')
    adjustmentMousePoint()
    move_mouse_to_image_in_process(meSobiPendant_image)
    double_click()
    press_arrow_left()
    press_arrow_left()
    pyautogui.keyUp('enter')
    press_esc()

def openCozam():
    press_key('i')
    time.sleep(.5)
    move_mouse_click_to_image_in_process(storageCozam_image)
    move_mouse_click_to_image_in_process(skillSetting1_image)
    for i in range(20):
        press_key('1')
        time.sleep(.5)
    time.sleep(3.5)
    enter()
    press_esc()

def settingVCore():
    press_key('k')
    time.sleep(.5)
    move_mouse_click_to_image_in_process(skillV_image)
    move_mouse_click_to_image_in_process(vMatrix_image)

    move_mouse_click_to_image_in_process(vSkill1_image)
    double_click()
    time.sleep(.5)
    adjustmentMousePoint()
    move_mouse_click_to_image_in_process(vSkill2_image)
    double_click()
    move_mouse_click_to_image_in_process(extractVCore_image)
    solve2Password()
    time.sleep(.5)
    move_mouse_click_to_image_in_process(vCoreAllSelect_image)
    move_mouse_click_to_image_in_process(extractVCore2_image)
    enter()
    time.sleep(3)
    move_mouse_click_to_image_in_process(vCoreMakeMode_image)
    move_mouse_click_to_image_in_process(vCoreMakeSkill1_image)
    move_mouse_click_to_image_in_process(vCoreMake_image)
    move_mouse_click_to_image_in_process(vCoreMake2_image)
    enter()

    scroll_mouse_down()
    time.sleep(.5)

    move_mouse_click_to_image_in_process(vCoreMakeSkill2_image)
    move_mouse_click_to_image_in_process(vCoreMake_image)
    move_mouse_click_to_image_in_process(vCoreMake2_image)
    enter()

    move_mouse_click_to_image_in_process(goToMyVCore_image)
    move_mouse_click_to_image_in_process(vSkill3_image)
    double_click()
    time.sleep(1)
    adjustmentMousePoint()
    time.sleep(1)
    move_mouse_click_to_image_in_process(vSkill4_image)
    double_click()
    press_esc()

def adjustmentMousePoint():
    pyautogui.moveTo(x + 50, y + 50)
    time.sleep(.5)

def wearSkills():
    press_key('k')
    time.sleep(.5)
    move_mouse_click_to_image_in_process(skillV_image, threshold=.95)
    move_mouse_click_to_image_in_process(shadow_spear_image)
    move_mouse_click_to_image_in_process(skill_pdn_image, threshold=.95)
    move_mouse_click_to_image_in_process(shadow_byte_image)
    move_mouse_click_to_image_in_process(skill_a_image, threshold=.95)
    move_mouse_click_to_image_in_process(shadow_byte_image)
    move_mouse_click_to_image_in_process(skill_hyper_image)
    move_mouse_click_to_image_in_process(dominian_image)
    move_mouse_click_to_image_in_process(skill_end_image, threshold=.95)
    press_key('e')
    time.sleep(.5)
    move_mouse_click_to_image_in_process(e_pet_image)
    move_mouse_click_to_image_in_process(sle_sim_image)
    move_mouse_click_to_image_in_process(e_pet_skill_image, threshold=.95)

    move_mouse_click_to_image_in_process(skillIV_image)
    move_mouse_click_to_image_in_process(quaterfle_srow_image)
    move_mouse_click_to_image_in_process(attack_image)
    adjustmentMousePoint()
    click()
    move_mouse_click_to_image_in_process(darkniess_oman_image)
    move_mouse_click_to_image_in_process(skill_shift_image, threshold=.95)

    move_mouse_click_to_image_in_process(skillIII_image)
    move_mouse_click_to_image_in_process(shadow_subunt_image)
    move_mouse_click_to_image_in_process(e_pet_skill_image, threshold=.95)

    move_mouse_click_to_image_in_process(skillI_image)
    move_mouse_click_to_image_in_process(shadow_bat_image)
    move_mouse_click_to_image_in_process(skill_2_party_image)
    adjustmentMousePoint()
    click()
    press_esc()
    press_esc()
    time.sleep(.5)
    press_key('2')
    time.sleep(.5)

def wearEquipment(num):
    press_key('i')
    time.sleep(.5)
    move_mouse_click_to_image_in_process(equipment_image)
    for i in range(1, num + 1):
        pyautogui.keyDown('enter')
        adjustmentMousePoint()
        move_mouse_to_image_in_process('images/items/' + str(i) + '.png', threshold=.95)
        double_click()
    pyautogui.keyUp('enter')
    press_esc()

def wearShinWha():
    press_key('i')
    time.sleep(.5)
    move_mouse_click_to_image_in_process(shuchi_image)
    move_mouse_to_image_in_process(yunhap_shinhwa2_image)
    double_click()
    press_esc()

def hunt():
    cnt = 0
    cnt2 = 0
    cnt3 = 0
    keyboard.press_and_release('pagedown')
    while True:
        if cnt == 30:
            time.sleep(1)
            win32api.keybd_event(0x27, 0, 0, 0)
            time.sleep(.2)
            win32api.keybd_event(0x27, 0, win32con.KEYEVENTF_KEYUP, 0)
            win32api.keybd_event(0x25, 0, 0, 0)
            time.sleep(.28)
            win32api.keybd_event(0x25, 0, win32con.KEYEVENTF_KEYUP, 0)
            cnt = 0
        if cnt2 == 60:
            time.sleep(1)
            keyboard.press_and_release('end')
            cnt2 = 0
        if cnt3 == 70:
            time.sleep(1)
            keyboard.press_and_release('pagedown')
            cnt3 = 0
        time.sleep(.8)
        keyboard.press_and_release('alt')
        keyboard.press_and_release('shift')
        keyboard.press_and_release('a')
        keyboard.press_and_release('ctrl')
        time.sleep(.1)
        keyboard.press_and_release('alt')
        cnt += 1
        cnt2 += 1
        cnt3 += 1

if __name__ == "__main__":
    # 찾을 이미지의 경로를 지정합니다.
    item_shop_image = 'images/item_shop.png'
    consumer_shop_image = 'images/consumer_shop.png'
    alicser_image = 'images/alicser.png'
    white_gold_star_image = 'images/white_gold_star.png'
    convenience_shop_image = 'images/convenience_shop.png'
    normal_pet_trade_image = 'images/normal_pet_trade.png'
    search_cash_image = 'images/search_cash.png'
    beauty_shop_image = 'images/beauty_shop.png'
    coin_shop_image = 'images/coin_shop.png'
    hunt_coin_shop_image = 'images/hunt_coin_shop.png'
    consumer_tap_image = 'images/consumer_tap.png'
    exp_1_image = 'images/exp_1.png'
    exp_2_image = 'images/exp_2.png'
    exp_3_image = 'images/exp_3.png'
    exp_4_image = 'images/exp_4.png'

    link_management_image = 'images/link_management.png'
    link_btn_image = 'images/link_btn.png'

    ability_point_image = 'images/ability_point.png'
    hyper_zero_image = 'images/hyper_zero.png'
    hyper1_image = 'images/hyper1.png'
    hyper2_image = 'images/hyper2.png'

    storageOne_image = 'images/storageOne.png'
    storageHip_image = 'images/storageHip.png'
    storageExit_image = 'images/storageExit.png'
    storage3xExp_image = 'images/storage3xExp.png'
    storage50Exp_image = 'images/storage50Exp.png'
    storagePirodo_image = 'images/storagePirodo.png'
    storagehuntCount_image = 'images/storagehuntCount.png'
    storageCozam_image = 'images/storageCozam.png'

    meCache_image = 'images/meCache.png'
    mePet_image = 'images/mePet.png'
    meChizang_image = 'images/meChizang.png'
    meChizangRing_image = 'images/meChizangRing.png'
    meChizangRing2_image = 'images/meChizangRing2.png'
    meSobi_image = 'images/meSobi.png'
    meSobiBox_image = 'images/meSobiBox.png'
    meSobiPendant_image = 'images/meSobiPendant.png'

    skillSetting1_image = 'images/skillSetting1.png'
    skill0_image = 'images/skill0.png'
    skillV_image = 'images/skillV.png'
    vMatrix_image = 'images/vMatrix.png'
    vSkill1_image = 'images/vSkill1.png'
    vSkill2_image = 'images/vSkill2.png'
    extractVCore_image = 'images/extractVCore.png'
    vCoreAllSelect_image = 'images/vCoreAllSelect.png'
    extractVCore2_image = 'images/extractVCore2.png'
    vCoreMakeMode_image = 'images/vCoreMakeMode.png'
    vCoreMakeSkill1_image = 'images/vCoreMakeSkill1.png'
    vCoreMakeSkill2_image = 'images/vCoreMakeSkill2.png'
    vCoreMake_image = 'images/vCoreMake.png'
    vCoreMake2_image = 'images/vCoreMake2.png'
    goToMyVCore_image = 'images/goToMyVCore.png'
    vSkill3_image = 'images/vSkill3.png'
    vSkill4_image = 'images/vSkill4.png'

    shadow_spear_image = 'images/shadow_spear.png'
    skill_pdn_image = 'images/skill_pdn.png'
    shadow_byte_image = 'images/shadow_byte.png'
    skill_a_image = 'images/skill_a.png'
    skill_hyper_image = 'images/skill_hyper.png'
    skill_hyper_active_image = 'images/skill_hyper_active.png'
    dominian_image = 'images/dominian.png'
    skill_end_image = 'images/skill_end.png'
    e_pet_image = 'images/e_pet.png'
    e_pet_skill_image = 'images/e_pet_skill.png'
    sle_sim_image = 'images/sle_sim.png'
    
    skillIV_image = 'images/skillIV.png'
    quaterfle_srow_image = 'images/quaterfle_srow.png'
    attack_image = 'images/attack.png'
    darkniess_oman_image = 'images/darkniess_oman.png'
    skill_shift_image = 'images/skill_shift.png'
    skillIII_image = 'images/skillIII.png'
    shadow_bat_image = 'images/shadow_bat.png'
    skillI_image = 'images/skillI.png'
    shadow_subunt_image = 'images/shadow_subunt.png'
    skill_2_party_image = 'images/skill_2_party.png'

    equipment_image = 'images/equipment.png'
    yunhap_shinhwa_image = 'images/yunhap_shinhwa.png'
    shuchi_image = 'images/shuchi.png'
    yunhap_shinhwa2_image = 'images/yunhap_shinhwa2.png'
    
    time.sleep(1)
    trigger = sys.argv[1]
    if trigger == 'hunt':
        hunt()
    elif trigger == '275':
        setLinkSkills()
        setStates()
        press_backtick()
        purchaseStar()
        purchasePets()
        purchaseRings()
        getItemByStorage(10)
        purchaseExpCoupon()
        press_esc()
        wearitems()
        openCozam()
        settingVCore()
        wearSkills()
        wearEquipment(19)
        wearShinWha()
    # TODO
    # 스킬 끼기 (작업 진행중)
    # 장비 끼기
    # 경쿠 먹기
